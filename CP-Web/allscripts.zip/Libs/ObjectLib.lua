ObjectLib = {
    Caitlyn = {
        Trap = "Cupcake Trap"
    },
    Gangplank = {
        Barrel = "Barrel"
    },
    Katarina = {
        Dagger = "HiddenMinion"
    },
    Zed = {
        Shadow = "Shadow"
    }
}
